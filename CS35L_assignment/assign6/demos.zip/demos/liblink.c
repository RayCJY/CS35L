#include <stdio.h>
#include "link.h"

static struct options opt;

static int next_int;
static int count;

void initialize(struct options init_opt) {
    opt = init_opt;
    next_int = opt.initial;
    count = 0;
}

int next() {
    int n = next_int;
    
    next_int += opt.stride;

    if (opt.period) {
        count++;
        if (count == opt.period) {
            next_int = opt.initial;
            count = 0;
        }
    }

    return n;
}

void finalize() {
    // If we had allocated any memory in initialize, we should free it here
    printf("Thanks for using my library :)\n");
}
