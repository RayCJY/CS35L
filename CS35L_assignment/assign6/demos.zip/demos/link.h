#ifndef LINK_H
#define LINK_H

#include <stdint.h>

/* This library provides functions to get an infinite, possibly periodic,
 * sequence of numbers with constant difference.
 */



struct options {
    int initial;
    int stride;     // Constant difference between two numbers
    int period;     // Sequence period. If period == 0, then not periodic.
};

void initialize(struct options opt);

int next();

void finalize();

#endif
