#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include "link.h"

int main(int argc, char **argv) {
    struct options opt = { .initial = 0, .stride = 1, .period = 0 };

    int c;
    while ((c = getopt(argc, argv, "i:s:p:")) != -1) {
        switch (c) {
        case 'i':
            opt.initial = atoi(optarg);
            break;
        case 's':
            opt.stride = atoi(optarg);
            break;
        case 'p':
            int period = atoi(optarg);
            if (period < 0)
                printf("Invalid period; period set to default (0)\n");
            else
                opt.period = period;
        }
    }

    if (optind >= argc) {
        printf("Need to provide size of sequence\n");
        return 1;
    }

    int seq_size = atoi(argv[optind]);

    if (seq_size < 0) {
        printf("Invalid sequence size\n");
        return 1;
    }

    initialize(opt);

    for (int i = 0; i < seq_size; i++) {
        printf("%d ", next());
    }

    printf("\n");

    finalize();
}
