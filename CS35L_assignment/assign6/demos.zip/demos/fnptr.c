#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>

typedef void (*sort_fn_t)(int *, size_t);

void merge_sort(int *arr, size_t count) {
    printf("We're doing merge sort!\n");
}

// bubble_sort has the same type as merge_sort since they have the same shape
// (not true in all languages: https://www.youtube.com/watch?v=SqT5YglW3qU)
void bubble_sort(int *arr, size_t count) {
    printf("We're doing bubble sort!\n");
}

void bogo_sort(int *arr, size_t count) {
    printf("We're doing bogo sort!\n");
}

void print_complexity(sort_fn_t fn) {
    // Can't use switch here; why?

    // switch (fn) {
    // case merge_sort:
    //     break;
    // case bubble_sort:
    //     break;
    // }

    if (fn == merge_sort) {
        printf("The complexity of merge sort is O(n log n)\n");
    } else if (fn == bubble_sort) {
        printf("The complexity of bubble sort is O(n^2)\n");
    } else if (fn == bogo_sort) {
        printf("The complexity of bogo sort is O(n!)\n");
    }
}

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Need a command line arg!\n");
        return 1;
    }

    // Equivalent (except for variable names)
    void (*hard_to_read)(int *, size_t) = merge_sort;
    sort_fn_t sort = merge_sort;

    if (strcmp(argv[1], "merge") == 0) {
        sort = merge_sort;
    } else if (strcmp(argv[1], "bubble") == 0) {
        sort = bubble_sort;
    } else {
        sort = bogo_sort;
    }

    int arr[] = {4, 1, 3, 2, 5};
    int count = sizeof(arr) / sizeof(int);
    sort(arr, count);
    print_complexity(sort);
}

// Super useful in testing! If we haven't implemented the compression algorithm
// yet, we can use a trivial implementation, copy, that simply copies the data
// so we can test the rest of the program.

typedef size_t (*read_fn_t)(char *, size_t);
typedef void (*write_fn_t)(const char *, size_t);

void compress(read_fn_t read, write_fn_t write) {
    // Implement compression algorithm here.
}

void copy(read_fn_t read, write_fn_t write) {
    char buf[1024];
    size_t bytes_read;
    while ((bytes_read = read(buf, sizeof(buf))))
        write(buf, bytes_read);
}
