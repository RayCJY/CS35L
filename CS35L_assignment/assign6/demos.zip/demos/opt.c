#include <unistd.h>
#include <errno.h>
#include <stdio.h>

/*
 * getopt global variables
 * optarg - The argument associated with the option
 * opterr - We set this to 1 or 0 to turn on or off diagnostic messages
 * optind - The index of the next command line argument; one past the current
 *          option and optarg (if any)
 * optopt - If the user provides an option without a optarg, getopt will return
 *          '?' and optopt will hold the error option
 */

int main(int argc, char **argv) {
    int option_char;

    // Leading colon in optstring allows us to distinguish unknown option vs. missing operand
    // No leading colon => getopt will automatically print a diagnostic message
    // Character in optstring followed by colon means that option needs an optarg
    while ((option_char = getopt(argc, argv, "a:bc:")) != -1) {
        switch (option_char) {
        case 'a':
            printf("You chose option a with optarg %s\n", optarg);
            break;
        case 'b':
            // No optarg for option b
            printf("You chose option b\n");
            break;
        case 'c':
            printf("You chose option c with optarg %s\n", optarg);
            break;
        case '?':
            printf("Invalid option %s\n", argv[optind - 1]);
            break;
        case ':':
            printf("You chose option %c but did not provide an optarg\n", optopt);
        }
    }
}
